package Ui;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class SubController {

	// ���ۺκ�
	@FXML
	private ImageView start;

	@FXML
	private ImageView start01;

	@FXML
	private ImageView start02;

	public void number01() {

		try {
			Parent login = FXMLLoader.load(getClass().getResource("play.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) start.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void number02() {

		try {
			Parent login = FXMLLoader.load(getClass().getResource("Drum.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) start01.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void number03() {

		try {
			Parent login = FXMLLoader.load(getClass().getResource("Xylophone.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) start02.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// �巳 �κ�

	@FXML
	private Button Back;

	public void Musical() {

		try {
			Parent login = FXMLLoader.load(getClass().getResource("Home.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) Back.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ���ڴ�
	@FXML
	private Button Back01;

	public void Musical01() {

		try {
			Parent login = FXMLLoader.load(getClass().getResource("Home.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) Back01.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// �Ƿ���
	@FXML
	private Button Back02;

	public void Musical02() {

		try {
			Parent login = FXMLLoader.load(getClass().getResource("Home.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) Back02.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ��뼳��
	@FXML
	private Button User;

	public void How() {

		try {
			Parent login = FXMLLoader.load(getClass().getResource("Use.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) User.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	private Button Back03;

	public void wayback() {

		try {
			Parent login = FXMLLoader.load(getClass().getResource("Home.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) Back03.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

