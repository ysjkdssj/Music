package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class MainController {

	// ���ۺκ�
	@FXML
	private Button start;

	@FXML
	private Button start01;

	@FXML
	private Button start02;

	public void number01() {

		try {
			Parent login = FXMLLoader.load(getClass().getResource("/Ui/play.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) start.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void number02() {

		try {
			Parent login = FXMLLoader.load(getClass().getResource("/Ui/Drum.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) start01.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void number03() {

		try {
			Parent login = FXMLLoader.load(getClass().getResource("/Ui/Drum.fxml"));
			Scene scene = new Scene(login);
			Stage primaryStage = (Stage) start02.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
